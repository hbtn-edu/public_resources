# 302 control node

Starter assets for **project 302 "Configuration Management with Ansible",
Task 1**. They ship inside the project directory the student receives:

```
302-ansible_configuration_management/
├── Dockerfile.control     # this directory
├── ssh_config             # this directory - baked into the image
└── ansible-lab/
    ├── ansible.cfg        # this directory
    ├── .yamllint.yml      # (in the project spec)
    └── ...                # everything else the student writes
```

The control node is a container so that every student runs the **same pinned
toolchain**, and so that nothing is installed on their own machine. Version
drift on the control node is itself a form of configuration drift, which is
the thing this project is about.

---

## Build

```bash
# From the directory containing Dockerfile.control, ssh_config and ansible-lab/
docker build -t ansible-control -f Dockerfile.control .
```

## Run

```bash
docker run -it --rm \
  -v "$(pwd)/ansible-lab:/work" \
  -v "$HOME/.ssh/id_ed25519:/home/ansible/.ssh/id_ed25519:ro" \
  ansible-control
```

The two mounts, and why they are what they are:

| Mount | Mode | Why |
|---|---|---|
| `./ansible-lab` → `/work` | read-**write** | Playbooks you edit on your host are visible inside the container immediately, and the run logs the container writes (`run1_install.txt`, `run2_site.txt`, ...) land on your host, where you submit them from. |
| `~/.ssh/id_ed25519` → `/home/ansible/.ssh/id_ed25519` | read-**only** (`:ro`) | The control node needs to *use* the key, never to change it. Read-only is one less way to damage or leak it — and it makes it impossible for a playbook bug to overwrite your key. |

`/work` is the working directory, so `ansible-playbook site.yml` works the
moment you land in the shell.

## Verify (Task 1, step 4)

```bash
ansible --version        # -> ansible [core 2.17.7]
ansible-lint --version   # -> ansible-lint 24.9.2 using ansible-core:2.17.7
yamllint --version       # -> yamllint 1.35.1
ls /work                 # -> your ansible-lab project files
```

Then prove the container can reach the managed node (Task 1, step 5):

```bash
ssh -i ~/.ssh/id_ed25519 -p <SANDBOX_PORT> <SANDBOX_USER>@<SANDBOX_HOST> "echo ok"
```

If that fails, fix it before touching Ansible: Ansible has no protocol of its
own, it shells out to this exact `ssh`.

---

## `Dockerfile.control`

Everything is pinned; nothing floats.

| Piece | Pin | Why it is there |
|---|---|---|
| `python:3.12-slim` | tag **and** digest | Small base, and Ansible is a Python program. The digest keeps the base identical after CPython patch releases. |
| `ansible-core` | `2.17.7` | The version Task 1 asks you to find in this file and confirm with `ansible --version`. |
| `ansible-lint` | `24.9.2` | Task 7. Everyone lints with the same rules. |
| `yamllint` | `1.35.1` | Task 7. |
| `openssh-client` | Debian package | The transport. This is what makes it a control node. |
| `git` | Debian package | `ansible-lint` shells out to git to decide which files belong to the project; without it every lint run opens with a warning. |

Two details worth reading before the quiz:

- **The build asserts its own pin.** After `pip install`, the Dockerfile runs
  `ansible --version | grep -q "core 2.17.7"`. If a dependency of
  `ansible-lint` ever drags in a different `ansible-core`, the build fails
  instead of quietly shipping a control node that lies about its version.
- **It runs as a non-root user (`ansible`, UID 1000).** Running the control
  node as root buys nothing: privilege escalation happens on the *managed*
  node, through `become`, not here. UID 1000 matches the usual first user
  account on Linux, which keeps the bind-mounted project files owned by you on
  the host side.

  If your host UID is not 1000 (macOS defaults to 501), the mounted private
  key will look like it belongs to someone else and OpenSSH will refuse it
  with `bad ownership or modes`. Two ways out:

  ```bash
  # a) run as your own UID
  docker run -it --rm --user "$(id -u):$(id -g)" ... ansible-control

  # b) or rebuild the image with your UID baked in
  docker build --build-arg UID=$(id -u) --build-arg GID=$(id -g) \
    -t ansible-control -f Dockerfile.control .
  ```

## `ssh_config`

Copied to `/home/ansible/.ssh/config` at build time. It disables host-key
checking **for the lab only** — the sandbox's host key changes every time the
sandbox is reset, and a `known_hosts` prompt hangs an `ansible-playbook` run
with no way to answer it. It is the SSH-client twin of
`host_key_checking = False` in `ansible.cfg`, and the file says in comments
what production does instead. Task 2 asks you to be able to explain this.

## `ansible.cfg`

The starter configuration for `ansible-lab/`. Ansible reads the `ansible.cfg`
in the current directory, which inside the container is `/work`. Confirm it is
the file in force with:

```bash
ansible-config dump --only-changed
# CONFIG_FILE() = /work/ansible.cfg
```

| Setting | Value | Why |
|---|---|---|
| `inventory` | `inventory.ini` | Stops you typing `-i inventory.ini` on every command. |
| `private_key_file` | `~/.ssh/id_ed25519` | Where the key is mounted inside the container. A host's `ansible_ssh_private_key_file` in the inventory overrides it. |
| `host_key_checking` | `False` | Lab only — see above. |
| `retry_files_enabled` | `False` | No stale `.retry` files next to your playbooks. |
| `interpreter_python` | `auto_silent` | Discover Python on the target without warning about the choice. The sandbox has 3.10.12 at `/usr/bin/python3`; the inventory pins it explicitly. |
| `stdout_callback` | `yaml` | Readable task output instead of one JSON blob per task. |
| `become` | `False` | Escalate where a task needs root, with `become: true`, not everywhere out of habit. |
| `ssh_args`, `pipelining` | connection reuse | Speed only; changes no behaviour. |

Every line carries the same explanation as a comment in the file itself,
because Task 2 asks you to read it line by line.
