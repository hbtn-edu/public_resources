# hbtn-devops-imagelab-python

A small Flask API shipped with a **deliberately bloated Dockerfile**.

This starter archive — `hbtn-devops-imagelab-python.zip`, from [the devops-labs folder of hbtn-edu/public_resources](https://github.com/hbtn-edu/public_resources/tree/main/devops-labs) —
is the starting point of **Part 2 of project 401 — Container
Images & Multi-stage Builds**. Part 1 taught you layers, build context, cache
ordering, multi-stage separation, minimal bases and non-root users on a Node.js
application. Here you get the same problem in a language you were not trained
on, and no step-by-step instructions. That is the whole exercise.

**Do not rewrite the application.** The work happens in the Dockerfile.

---

## The application

`app.py` is a catalogue of image metadata kept in memory. It has no database, no
external service and no state that survives a restart, so it behaves identically
whichever image you run it from.

| Method | Path            | Response                                              |
|--------|-----------------|-------------------------------------------------------|
| `GET`  | `/health`       | `200` `{"status": "ok"}`                               |
| `GET`  | `/images`       | `200` `{"count": n, "etag": "...", "images": [...]}`   |
| `GET`  | `/images/<id>`  | `200` the image, or `404` `{"error": "..."}`           |
| `POST` | `/images`       | `201` the created image, or `400` `{"errors": [...]}`  |
| `GET`  | `/stats`        | `200` `{"count": n, "total_pixels": n}`                |

The API listens on port **8000**.

```bash
curl -s http://localhost:8000/health
# {"status":"ok"}

curl -s -X POST http://localhost:8000/images \
     -H 'Content-Type: application/json' \
     -d '{"name":"delta.png","width":320,"height":240}'
# 201 {"id":4,"name":"delta.png","width":320,"height":240,"format":"png"}
```

---

## Dependencies

`requirements.txt` holds the runtime dependencies, pinned exactly.
`requirements-dev.txt` holds the test runner, and only the test runner.

One entry is worth noticing: **`xxhash` is installed from source, not from a
prebuilt wheel** (`--no-binary=xxhash` at the top of the file). It carries a C
extension, so `pip install` genuinely needs a C compiler here, on every
architecture. Nothing at run time does. Keep that in mind when you decide what
belongs in which stage.

Without a compiler the install stops with an unmistakable message:

```
error: command 'gcc' failed: No such file or directory
```

---

## Running the test suite

Ten tests live in `tests/test_app.py`. They run in two modes with the same
assertions, so the same suite validates the application before and after you
optimise the image.

**In process** — drives the Flask app directly:

```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
pytest
```

**Against a running container** — set `APP_BASE_URL` and the suite talks HTTP:

```bash
docker run -d --name imagelab -p 8000:8000 imagelab:baseline
APP_BASE_URL=http://localhost:8000 pytest
docker rm -f imagelab
```

The HTTP mode uses the standard library only, so it needs no extra package.

---

## The baseline image

```bash
docker build -f Dockerfile -t imagelab:baseline .
docker images imagelab:baseline
docker history imagelab:baseline
```

`Dockerfile` is the baseline, and it is bad on purpose — its header comment
lists the reasons. Build it first and write down the number: everything you do
next is measured against it.

---

## What this archive does *not* ship

Two files are missing, and producing them is the exercise:

- `.dockerignore`
- `Dockerfile.optimized`

Read Task 6 of project 401 for the constraints your optimised image has to
satisfy (runtime base, stage split, non-root user, hadolint, and the size
reduction target). Then measure, and check the application still answers.
