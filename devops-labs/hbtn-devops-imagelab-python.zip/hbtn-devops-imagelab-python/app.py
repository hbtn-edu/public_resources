"""imagelab — a deliberately small Flask API.

The application is not the point of the exercise: it exists so that the
container shipping it has something real to run, and so that you can prove the
image still works after you have shrunk it. Do not rewrite it — the work of
project 401 Part 2 happens in the Dockerfile, not here.

Endpoints
---------
GET  /health            -> 200 {"status": "ok"}
GET  /images            -> 200 {"count": n, "etag": "...", "images": [...]}
GET  /images/<id>       -> 200 <image> | 404 {"error": "..."}
POST /images            -> 201 <image> | 400 {"errors": [...]}
GET  /stats             -> 200 {"count": n, "total_pixels": n}

The catalogue lives in memory, which is why the container serves the app with a
single worker: several worker processes would each hold their own copy and
answer differently. See the CMD instruction in the Dockerfile.
"""

from __future__ import annotations

import json
import os
from threading import Lock

import xxhash
from flask import Flask, jsonify, request

MAX_NAME_LENGTH = 120
MAX_DIMENSION = 20000
DEFAULT_PORT = 8000

SEED_IMAGES = [
    {"name": "alpha.png", "width": 800, "height": 600, "format": "png"},
    {"name": "beta.jpg", "width": 1920, "height": 1080, "format": "jpeg"},
    {"name": "gamma.webp", "width": 640, "height": 640, "format": "webp"},
]


def checksum(payload) -> str:
    """Stable 64-bit digest of a JSON-serialisable value.

    xxhash is a C extension: this single call is why building this project
    needs a compiler, and why the built artefact must be carried across the
    stage boundary rather than rebuilt at run time.
    """
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return xxhash.xxh64_hexdigest(encoded)


def validate_image(payload) -> list[str]:
    """Return the list of validation errors for an image-creation payload.

    An empty list means the payload is acceptable.
    """
    if not isinstance(payload, dict):
        return ["request body must be a JSON object"]

    errors: list[str] = []

    name = payload.get("name")
    if not isinstance(name, str) or not name.strip():
        errors.append("name is required and must be a non-empty string")
    elif len(name) > MAX_NAME_LENGTH:
        errors.append(f"name must be at most {MAX_NAME_LENGTH} characters")

    for field in ("width", "height"):
        value = payload.get(field)
        if not isinstance(value, int) or isinstance(value, bool):
            errors.append(f"{field} is required and must be an integer")
        elif not 1 <= value <= MAX_DIMENSION:
            errors.append(f"{field} must be between 1 and {MAX_DIMENSION}")

    return errors


def build_image(image_id: int, payload: dict) -> dict:
    """Turn a validated payload into a catalogue entry."""
    image = {
        "id": image_id,
        "name": payload["name"].strip(),
        "width": payload["width"],
        "height": payload["height"],
        "format": payload.get("format", "png"),
    }
    image["checksum"] = checksum(image)
    return image


def create_app() -> Flask:
    """Build the Flask application with a fresh in-memory catalogue."""
    app = Flask(__name__)
    store = [
        build_image(index + 1, image) for index, image in enumerate(SEED_IMAGES)
    ]
    lock = Lock()

    @app.get("/health")
    def health():
        return jsonify(status="ok"), 200

    @app.get("/images")
    def list_images():
        with lock:
            images = list(store)
        return (
            jsonify(count=len(images), etag=checksum(images), images=images),
            200,
        )

    @app.get("/images/<int:image_id>")
    def get_image(image_id: int):
        with lock:
            for image in store:
                if image["id"] == image_id:
                    return jsonify(image), 200
        return jsonify(error=f"image {image_id} not found"), 404

    @app.post("/images")
    def create_image():
        payload = request.get_json(silent=True)
        errors = validate_image(payload)
        if errors:
            return jsonify(errors=errors), 400

        with lock:
            image = build_image(store[-1]["id"] + 1 if store else 1, payload)
            store.append(image)
        return jsonify(image), 201

    @app.get("/stats")
    def stats():
        with lock:
            total_pixels = sum(image["width"] * image["height"] for image in store)
            return jsonify(count=len(store), total_pixels=total_pixels), 200

    return app


app = create_app()


if __name__ == "__main__":
    # Development entry point only. The container serves the app through
    # gunicorn; see the CMD instruction in the Dockerfile.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", DEFAULT_PORT)))
