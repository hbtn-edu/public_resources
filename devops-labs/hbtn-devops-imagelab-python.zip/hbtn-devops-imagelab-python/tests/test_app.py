"""Tests for the imagelab API.

The same suite runs in two modes, so the exact same assertions can be used
before and after you optimise the image:

  * in process (default) — the tests drive the Flask application directly;
  * over HTTP — set ``APP_BASE_URL`` and the tests talk to a running container.

    docker run -d --name imagelab -p 8000:8000 imagelab:baseline
    APP_BASE_URL=http://localhost:8000 pytest -q

Only the standard library is used for the HTTP mode, so no extra dependency is
needed to check a running container.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

import pytest

from app import MAX_DIMENSION, create_app

BASE_URL = os.environ.get("APP_BASE_URL")
TIMEOUT_SECONDS = 10


class HttpClient:
    """Minimal JSON client for a live instance of the API."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url.rstrip("/")

    def _call(self, method: str, path: str, payload=None):
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.base_url + path,
            data=body,
            method=method,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read().decode("utf-8"))

    def get(self, path: str):
        return self._call("GET", path)

    def post(self, path: str, payload):
        return self._call("POST", path, payload)


class FlaskTestClient:
    """The same interface, backed by Flask's in-process test client."""

    def __init__(self) -> None:
        self._client = create_app().test_client()

    def get(self, path: str):
        response = self._client.get(path)
        return response.status_code, response.get_json()

    def post(self, path: str, payload):
        response = self._client.post(path, json=payload)
        return response.status_code, response.get_json()


@pytest.fixture()
def client():
    if BASE_URL:
        return HttpClient(BASE_URL)
    return FlaskTestClient()


def test_health_returns_ok(client):
    status, body = client.get("/health")
    assert status == 200
    assert body == {"status": "ok"}


def test_list_images_returns_a_catalogue(client):
    status, body = client.get("/images")
    assert status == 200
    assert isinstance(body["images"], list)
    assert body["count"] == len(body["images"])
    assert body["count"] >= 3
    # The catalogue digest comes from the xxhash C extension.
    assert len(body["etag"]) == 16
    assert int(body["etag"], 16) >= 0


def test_every_image_carries_the_expected_fields(client):
    _, body = client.get("/images")
    for image in body["images"]:
        assert {"id", "name", "width", "height", "format", "checksum"} <= set(image)
        assert isinstance(image["id"], int)
        assert isinstance(image["name"], str) and image["name"]
        assert len(image["checksum"]) == 16


def test_single_image_can_be_fetched_by_id(client):
    _, listing = client.get("/images")
    first = listing["images"][0]
    status, body = client.get(f"/images/{first['id']}")
    assert status == 200
    assert body["id"] == first["id"]
    assert body["name"] == first["name"]


def test_unknown_image_returns_404(client):
    status, body = client.get("/images/999999")
    assert status == 404
    assert "error" in body


def test_creating_an_image_returns_201(client):
    status, body = client.post(
        "/images", {"name": "delta.png", "width": 320, "height": 240}
    )
    assert status == 201
    assert isinstance(body["id"], int)
    assert body["name"] == "delta.png"
    assert body["format"] == "png"
    assert len(body["checksum"]) == 16


def test_a_created_image_joins_the_catalogue(client):
    _, before = client.get("/images")
    status, created = client.post(
        "/images", {"name": "epsilon.png", "width": 100, "height": 100}
    )
    assert status == 201

    _, after = client.get("/images")
    assert after["count"] == before["count"] + 1
    assert created["id"] in [image["id"] for image in after["images"]]


def test_creating_an_image_without_a_name_returns_400(client):
    status, body = client.post("/images", {"width": 100, "height": 100})
    assert status == 400
    assert any("name" in message for message in body["errors"])


def test_creating_an_image_with_a_bad_dimension_returns_400(client):
    status, body = client.post(
        "/images", {"name": "bad.png", "width": "wide", "height": MAX_DIMENSION + 1}
    )
    assert status == 400
    assert any("width" in message for message in body["errors"])
    assert any("height" in message for message in body["errors"])


def test_stats_match_the_catalogue(client):
    _, listing = client.get("/images")
    _, stats = client.get("/stats")
    assert stats["count"] == listing["count"]
    assert stats["total_pixels"] == sum(
        image["width"] * image["height"] for image in listing["images"]
    )
