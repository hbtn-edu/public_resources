# hbtn-devops-pipeline-lab

The lab application for **project 501 — CI/CD Pipeline Essentials**.

It is a small, already-tested Express API backed by Postgres. You do **not**
write the application or its tests: you automate their execution in a pipeline,
starting from a `.github/workflows/ci.yml` that is deliberately broken.

Fork this repository into your own account, then work in your fork.

---

## What is in here

```
src/
  server.js                    Express app: JSON body parsing, routes, error handling
  routes/health.js             GET /health
  routes/items.js              GET /items, POST /items, and the name validator
  db/connection.js             lazy Postgres pool, built from DATABASE_URL
  db/migrate.js                idempotent migration runner
  db/migrations/*.sql          schema and seed
tests/
  unit/health.test.js          3 unit tests
  unit/items.unit.test.js      5 unit tests
  integration/items.int.test.js  3 integration tests (needs Postgres)
Dockerfile                     multi-stage: builder (dev deps) + runtime (production)
docker-compose.yml             app + db, for local runs
jest.config.js                 jest-junit reporter installed, not enabled by default
.eslintrc.json                 lint rules behind `npm run lint`
.github/workflows/ci.yml       DELIBERATELY BROKEN — three faults to repair
```

**11 deterministic tests in total: 8 unit + 3 integration.** The unit tests need
nothing but Node. The integration tests need a reachable Postgres.

---

## The API

| Method | Path      | Behaviour                                                       |
|--------|-----------|------------------------------------------------------------------|
| `GET`  | `/health` | `200` `{"status":"ok"}` — process liveness, does not touch the db |
| `GET`  | `/items`  | `200` the stored items, oldest first                              |
| `POST` | `/items`  | `201` the created item, or `400` `{"error":"..."}` when the name is invalid |

The app listens on port **3000**. It reads its database connection from the
`DATABASE_URL` environment variable and nothing else; there is no default and no
fallback, so a missing variable fails immediately with a message that says so.

---

## Running it — everything in containers

You do **not** need Node or npm on your machine, and the project asks you not to
install them. Every command below runs inside the image.

```bash
docker compose up -d                                  # start app + database
docker compose ps                                     # both services running?

docker compose run --rm app npm run test:unit         # 8 unit tests, no db needed
docker compose run --rm app npm run test:integration  # 3 integration tests
docker compose run --rm app npm test                  # the whole suite, 11 tests
docker compose run --rm app npm run lint              # eslint

curl -s http://localhost:3000/health                  # {"status":"ok"}
curl -s http://localhost:3000/items
curl -s -X POST http://localhost:3000/items \
     -H 'Content-Type: application/json' \
     -d '{"name":"Delta Item"}'                       # 201

docker compose down -v                                # stop, and drop the volumes
```

The compose `app` service builds the **builder** stage of the `Dockerfile`,
which is the one carrying the development dependencies — that is what makes
`jest`, `supertest` and `eslint` available inside the container.

---

## The pipeline

`.github/workflows/ci.yml` is **deliberately broken**. It contains three faults
of three different kinds, and each one fails in its own recognisable way. Task 2
of the project has you find them by reading the run logs and repair them in
three separate commits.

Resist the temptation to rewrite the file. Everything you need is in the Actions
tab: the run conclusion, the annotations, and the log of the step that failed.

Tasks 3 to 5 then extend the same file with dependency caching, test-report
artifacts, an image build pushed to GHCR, and a deployment job.

---

## Troubleshooting

| Symptom | What to do |
|---|---|
| `DATABASE_URL is not set` | The process has no connection string. Locally, compose sets it for you — check you are running through `docker compose`. |
| Integration tests hang or refuse the connection | Is the database up and healthy? `docker compose ps` |
| Changes to `package.json` seem ignored in the container | The `node_modules` volume is stale: `docker compose down -v` then `docker compose build` |
| `npm ci` complains about the lock file | Regenerate it **in the container**: `docker compose run --rm app npm install`, then commit the result |
| Port 3000 already in use | Something else is bound to it; stop it, or change the published port in `docker-compose.yml` |
