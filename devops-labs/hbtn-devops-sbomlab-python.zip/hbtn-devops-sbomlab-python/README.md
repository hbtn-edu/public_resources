# hbtn-devops-sbomlab-python

Starter repository for the Holberton DevOps project **602 - SBOM & Software
Composition Analysis**.

> ## This repository depends on known-vulnerable packages on purpose
>
> Every version in `requirements.txt` is deliberately old and carries at least
> one publicly documented vulnerability. That is the whole point: you are going
> to inventory these dependencies, describe them in two SBOM formats, scan them,
> triage the findings and remediate them.
>
> **Do not run this application in any network-facing capacity, and do not
> change the pins before the remediation task** - the pins are what make the
> findings reproducible.

## Layout

| Path | What it is |
|---|---|
| `app.py` | Flask API: `/health`, a small tasks CRUD, `/tasks/report`, `/auth/token`, `/notify` |
| `auth.py` | Token issue/verify helpers (PyJWT) |
| `notify.py` | Outbound HTTP with an explicit retry policy (requests + urllib3) |
| `templates.py` | HTML report rendering (Jinja2) |
| `config.yaml` | Settings, loaded with PyYAML |
| `requirements.txt` | The six pinned dependencies - the heart of this lab |
| `constraints-baseline.txt` | Optional, see *Running the app* below |
| `tests/` | Standard-library `unittest` suite, no extra dependencies |
| `remediation_record.md` | The table template you fill in |

The application is a thin excuse for its dependency set, but every pinned
package is genuinely imported and genuinely used, so the inventory and the
SBOMs you generate from it are honest.

## The dependency set

Six direct dependencies, all pinned with `==`:

```
flask==2.0.1
requests==2.25.1
urllib3==1.26.4
PyJWT==2.3.0
PyYAML==5.3.1
Jinja2==3.0.3
```

Two of them are also somebody else's dependency (`flask` requires `Jinja2`,
`requests` requires `urllib3`). Pinning a package does not remove it from the
dependency graph - that observation is part of the first task.

## Setting up

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

On Python 3.10 this produces **13 application packages** (the six pins plus
seven transitive ones: `certifi`, `chardet`, `click`, `idna`, `itsdangerous`,
`MarkupSafe`, `Werkzeug`), on top of the `pip`/`setuptools` that every virtual
environment starts with.

### Install the analysis tooling in a *separate* environment

`pip-audit` requires `requests >= 2.31`, and `pipdeptree` 4.x requires
`urllib3 >= 2.0`. Installing either one into the lab environment silently
**upgrades two of the six pins** - measured: `requests` 2.25.1 -> 2.34.2 and
`urllib3` 1.26.4 -> 2.7.0. That changes your inventory, adds around forty
tooling packages to your dependency tree, and hides two of the findings you are
supposed to see. Keep the tools in their own environment:

```bash
python3 -m venv ~/.sbomlab-tools
~/.sbomlab-tools/bin/pip install pipdeptree pip-audit

# point the tools at the lab environment instead of installing into it
~/.sbomlab-tools/bin/pipdeptree --python .venv/bin/python
~/.sbomlab-tools/bin/pipdeptree --python .venv/bin/python --json > pipdeptree.json
~/.sbomlab-tools/bin/pip-audit -r requirements.txt
```

`pip-audit -r requirements.txt` audits the pinned file directly and never
touches the environment, so it is safe either way. Keep the tools environment
outside the project directory - anything inside it ends up in a directory-scan
SBOM.

(If you would rather install the tree tool locally, `pipdeptree==2.23.4` has no
`urllib3` requirement and leaves the pins alone. `pip-audit` has no such
version.)

## Running the app and the tests

```bash
python3 -m unittest discover -s tests -t . -v
```

On the seeded baseline the application tests are **skipped**, with an
explanatory message, and the two `requirements` tests run. This is expected:
`flask==2.0.1` declares `Werkzeug>=2.0` with no upper bound, so pip resolves a
Werkzeug 3.x that Flask 2.0.1 cannot import (`ImportError: cannot import name
'url_quote' from 'werkzeug.urls'`). None of the graded work needs the
application to run.

If you want the baseline to actually start, add the optional constraints file -
it pins the transitive packages only and leaves `requirements.txt` untouched:

```bash
pip install -r requirements.txt -c constraints-baseline.txt
python3 -m unittest discover -s tests -t . -v   # all 8 tests run
python3 app.py                                  # http://127.0.0.1:5000/health
```

Take your Task 1 inventory from a plain `pip install -r requirements.txt`
without the constraints file, otherwise your package counts will not match the
pins.

## Known environment gotchas

| Symptom | What is going on |
|---|---|
| `ImportError: cannot import name 'url_quote' from 'werkzeug.urls'` | Old Flask against a modern Werkzeug - see above. Also affects Flask 2.2.x, whose test client needs `werkzeug.__version__`, removed in Werkzeug 3.0. |
| `AttributeError: 'build_ext' object has no attribute 'cython_sources'` while installing PyYAML | PyYAML 5.4.x does not build against modern Cython. The 5.3.1 baseline builds fine; if you need a newer PyYAML, use the 6.x line. |
| grype's `VULNERABILITY` column shows `GHSA-...`, not `CVE-...` | grype reports the GitHub advisory as the primary identifier. The CVE aliases are in the JSON report under `.matches[].relatedVulnerabilities[].id`. |
| pip-audit reports `PYSEC-...` identifiers | Same idea: `pip-audit -f json` carries the CVE under `.dependencies[].vulns[].aliases`. |
| An SPDX SBOM of the directory has far more packages than the CycloneDX one | `syft dir:.` walks everything on disk, including `.venv/` and the launcher stubs inside `setuptools`. `cdxgen -t python` reads the manifest. Two honest SBOMs of the same directory, different scopes - worth explaining in your write-up. Use `syft dir:. --exclude './.venv/**'` if you want them comparable. |

## Verified against

This starter was checked end to end with the toolchain below. The six pins
install cleanly together, produce a 13-component CycloneDX 1.5 SBOM with a
`pkg:pypi/...` purl for every component, and are reported as vulnerable by both
scanners.

| Tool | Version |
|---|---|
| Python | 3.10.12 |
| cdxgen | 11.10.0 |
| syft | 1.33.0 |
| grype | 0.100.0 |
| pip-audit | 2.10.1 |
| pipdeptree | 4.2.0 |
