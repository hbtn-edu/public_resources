"""Flask API for the SBOM & Software Composition Analysis lab.

The application is a thin excuse for its dependency set: it is small on purpose,
but every one of the six pinned packages in ``requirements.txt`` is genuinely
imported and genuinely used, so the inventory and the SBOMs generated from this
project are honest.

    flask     -> the HTTP layer below
    PyYAML    -> loads config.yaml
    PyJWT     -> auth.py, reached through POST /auth/token
    requests  -> notify.py, reached through POST /notify
    urllib3   -> notify.py's retry policy (and requests' own transport)
    Jinja2    -> templates.py, reached through GET /tasks/report

This application is intentionally built on vulnerable dependency versions. Do
not expose it on a network.
"""

from __future__ import annotations

import pathlib
from importlib import metadata
from typing import Any

import yaml
from flask import Flask, jsonify, request

import auth
import notify
import templates

CONFIG_PATH = pathlib.Path(__file__).with_name("config.yaml")

#: Distribution names as PyPI knows them, used for the /health report.
PINNED_DISTRIBUTIONS = ("flask", "requests", "urllib3", "PyJWT", "PyYAML", "Jinja2")


def load_config(path: pathlib.Path = CONFIG_PATH) -> dict[str, Any]:
    """Read the YAML settings file.

    ``yaml.safe_load`` is used rather than ``yaml.load``/``full_load``: the
    unsafe loaders can instantiate arbitrary Python objects from a document,
    which is the behaviour behind PyYAML's deserialisation advisories.
    """
    with open(path, "r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def dependency_versions() -> dict[str, str]:
    """Report the installed version of every pinned distribution."""
    versions = {}
    for distribution in PINNED_DISTRIBUTIONS:
        try:
            versions[distribution] = metadata.version(distribution)
        except metadata.PackageNotFoundError:
            versions[distribution] = "not installed"
    return versions


def create_app(config: dict[str, Any] | None = None) -> Flask:
    settings = config or load_config()
    app = Flask(settings["app"]["name"])
    app.config["SETTINGS"] = settings

    tasks: list[dict[str, Any]] = [
        {"id": 1, "name": "Generate a CycloneDX SBOM", "done": False},
        {"id": 2, "name": "Generate an SPDX SBOM", "done": False},
        {"id": 3, "name": "Scan the SBOM for known vulnerabilities", "done": False},
    ]
    next_id = {"value": len(tasks) + 1}

    def find(task_id: int) -> dict[str, Any] | None:
        return next((task for task in tasks if task["id"] == task_id), None)

    @app.get("/health")
    def health():
        return jsonify(
            {
                "status": "ok",
                "service": settings["app"]["name"],
                "environment": settings["app"]["environment"],
                "dependencies": dependency_versions(),
            }
        )

    @app.get("/tasks")
    def list_tasks():
        return jsonify({"tasks": tasks, "total": len(tasks)})

    @app.get("/tasks/<int:task_id>")
    def get_task(task_id: int):
        task = find(task_id)
        if task is None:
            return jsonify({"error": "not_found"}), 404
        return jsonify(task)

    @app.post("/tasks")
    def create_task():
        payload = request.get_json(silent=True) or {}
        name = payload.get("name")
        if not isinstance(name, str) or not name.strip():
            return jsonify({"error": "validation_failed", "detail": "name is required"}), 400

        task = {"id": next_id["value"], "name": name.strip(), "done": bool(payload.get("done"))}
        next_id["value"] += 1
        tasks.append(task)
        return jsonify(task), 201

    @app.delete("/tasks/<int:task_id>")
    def delete_task(task_id: int):
        task = find(task_id)
        if task is None:
            return jsonify({"error": "not_found"}), 404
        tasks.remove(task)
        return "", 204

    @app.get("/tasks/report")
    def task_report():
        html = templates.render_task_report(settings["report"]["title"], tasks)
        return html, 200, {"Content-Type": "text/html; charset=utf-8"}

    @app.post("/auth/token")
    def issue_token():
        payload = request.get_json(silent=True) or {}
        username = payload.get("username")
        if not isinstance(username, str) or not username.strip():
            return jsonify({"error": "validation_failed", "detail": "username is required"}), 400

        token = auth.issue_token(
            username.strip(),
            signing_key=settings["auth"]["signing_key"],
            algorithm=settings["auth"]["algorithm"],
            ttl_seconds=settings["auth"]["token_ttl_seconds"],
        )
        return jsonify({"token": token, "expires_in": settings["auth"]["token_ttl_seconds"]})

    @app.post("/notify")
    def send_notification():
        retries = settings["notifications"]["retries"]
        session = notify.build_session(
            total=retries["total"],
            backoff_factor=retries["backoff_factor"],
            status_forcelist=retries["status_forcelist"],
        )
        status = notify.send_digest(
            settings["notifications"]["webhook_url"],
            tasks,
            timeout=settings["notifications"]["timeout_seconds"],
            session=session,
        )
        return jsonify({"webhook_status": status})

    return app


app = create_app()


if __name__ == "__main__":
    settings = app.config["SETTINGS"]
    app.run(host=settings["app"]["host"], port=settings["app"]["port"])
