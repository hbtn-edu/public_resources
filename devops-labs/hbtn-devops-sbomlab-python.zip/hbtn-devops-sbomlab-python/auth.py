"""Token issue and verification helpers.

Uses PyJWT. Kept deliberately small: the point of this module is that PyJWT is
genuinely exercised by the application, so it belongs in the dependency
inventory and in every SBOM generated from this project.
"""

from __future__ import annotations

import datetime
from typing import Any, Iterable

import jwt


def issue_token(
    subject: str,
    *,
    signing_key: str,
    algorithm: str = "HS256",
    ttl_seconds: int = 900,
    issued_at: datetime.datetime | None = None,
) -> str:
    """Return a signed, time-limited token for ``subject``."""
    now = issued_at or datetime.datetime.now(datetime.timezone.utc)
    payload = {
        "sub": subject,
        "iat": now,
        "exp": now + datetime.timedelta(seconds=ttl_seconds),
    }
    return jwt.encode(payload, signing_key, algorithm=algorithm)


def verify_token(
    token: str,
    *,
    signing_key: str,
    algorithms: Iterable[str] = ("HS256",),
) -> dict[str, Any]:
    """Decode ``token``, raising ``jwt.PyJWTError`` if it is not valid.

    The allowed algorithms are always passed explicitly. Trusting the ``alg``
    field advertised in the token header instead is the class of bug that
    algorithm-confusion advisories against this library describe.
    """
    return jwt.decode(token, signing_key, algorithms=list(algorithms))
