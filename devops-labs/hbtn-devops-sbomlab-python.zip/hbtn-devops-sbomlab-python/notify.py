"""Outbound HTTP notifications with an explicit retry policy.

Uses ``requests`` for the transport and ``urllib3``'s ``Retry`` for the retry
policy. ``urllib3`` is also a transitive dependency of ``requests``: it appears
in ``requirements.txt`` *and* underneath ``requests`` in the dependency tree,
which is exactly the situation Task 1 asks about.
"""

from __future__ import annotations

from typing import Any, Iterable

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

DEFAULT_STATUS_FORCELIST = (429, 500, 502, 503, 504)


def build_session(
    *,
    total: int = 3,
    backoff_factor: float = 0.3,
    status_forcelist: Iterable[int] = DEFAULT_STATUS_FORCELIST,
) -> requests.Session:
    """Return a ``requests`` session that retries idempotent failures."""
    retry = Retry(
        total=total,
        backoff_factor=backoff_factor,
        status_forcelist=list(status_forcelist),
        allowed_methods=frozenset(["GET", "POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)

    session = requests.Session()
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def send_digest(
    webhook_url: str,
    tasks: list[dict[str, Any]],
    *,
    timeout: int = 5,
    session: requests.Session | None = None,
) -> int:
    """POST a summary of ``tasks`` to ``webhook_url`` and return the status code."""
    http = session or build_session()
    response = http.post(
        webhook_url,
        json={"open": sum(1 for task in tasks if not task["done"]), "total": len(tasks)},
        timeout=timeout,
    )
    return response.status_code
