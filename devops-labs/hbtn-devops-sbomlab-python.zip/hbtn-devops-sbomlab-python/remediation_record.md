# Remediation Record — sbomlab-python

- Scan date: <YYYY-MM-DD>   - Tools: grype <ver>, pip-audit <ver>
- Baseline SBOM: sbom.cdx.json   - Remediated SBOM: sbom.cdx.remediated.json

| # | CVE | Package@Version | Severity (CVSS) | Fix version | Decision | Action | Verified | Notes |
|---|-----|-----------------|-----------------|-------------|----------|--------|----------|-------|
| 1 | CVE-YYYY-NNNNN | name@x.y.z | Critical (9.8) | a.b.c | Fix now | bumped to a.b.c | absent from re-scan <date> | |
| 2 | ... | ... | ... | ... | ... | ... | ... | |

## Summary
- Fixed: <n>   - Accepted: <n>   - Mitigated: <n>   - Total: <n>

---

### How to fill this in

- One row per finding from the scan task — none skipped.
- **Decision** is one of: `Fix now` (Critical/High with a fix available),
  `Fix soon` (Medium with a fix available), `Accept risk` (Low, or no fix
  available — put the rationale in *Notes*), `Mitigate` (no direct fix but a
  workaround exists).
- **Action** and **Verified** stay empty until the remediation task: an updated
  pin is a claim, the re-scan is the proof.
- Use *Notes* for exploitability context — EPSS probability, whether the
  vulnerable code path is reachable from this application, compensating
  controls.
- Replace every `<placeholder>`. No angle brackets should remain in the
  submitted file.
