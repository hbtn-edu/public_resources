"""HTML report rendering.

Uses Jinja2, which is also a direct dependency of Flask. Pinning it in
``requirements.txt`` does not change that: it stays a dependency of ``flask``
in the tree, which is why it does not show up under ``pip list --not-required``.
"""

from __future__ import annotations

from typing import Any

from jinja2 import Environment, select_autoescape

REPORT_TEMPLATE = """<!doctype html>
<html lang="en">
  <head><title>{{ title }}</title></head>
  <body>
    <h1>{{ title }}</h1>
    <p>{{ open_count }} open of {{ tasks | length }} total.</p>
    <ul>
      {% for task in tasks %}
      <li{% if task.done %} class="done"{% endif %}>{{ task.name }}</li>
      {% endfor %}
    </ul>
  </body>
</html>
"""

_environment = Environment(
    autoescape=select_autoescape(default=True, default_for_string=True),
    trim_blocks=True,
    lstrip_blocks=True,
)


def render_task_report(title: str, tasks: list[dict[str, Any]]) -> str:
    """Render ``tasks`` as a small standalone HTML page."""
    template = _environment.from_string(REPORT_TEMPLATE)
    return template.render(
        title=title,
        tasks=tasks,
        open_count=sum(1 for task in tasks if not task["done"]),
    )
