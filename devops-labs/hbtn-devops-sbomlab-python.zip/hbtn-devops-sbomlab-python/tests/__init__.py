"""Test package for the SBOM & SCA lab starter."""
