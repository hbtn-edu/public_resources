"""Functional checks on the Flask application.

Run from the repository root:

    python3 -m unittest discover -s tests -t . -v

The whole module is skipped when the application cannot be imported. That is
the expected result on the seeded baseline: ``flask==2.0.1`` declares no upper
bound on Werkzeug, so a plain ``pip install -r requirements.txt`` resolves a
Werkzeug 3.x that Flask 2.0.1 cannot import. See the README for the optional
constraints file that makes the baseline runnable. After the remediation task,
these tests run normally.
"""

import unittest

try:
    import app as sbomlab
    import auth
    import templates
except ImportError as exc:  # pragma: no cover - environment-dependent
    raise unittest.SkipTest(f"application dependencies are not importable: {exc}") from exc


class ApplicationTest(unittest.TestCase):
    def setUp(self):
        self.settings = sbomlab.load_config()
        self.app = sbomlab.create_app(self.settings)
        self.client = self.app.test_client()

    def test_health_reports_ok_and_the_pinned_dependency_versions(self):
        response = self.client.get("/health")

        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(
            sorted(body["dependencies"]),
            sorted(sbomlab.PINNED_DISTRIBUTIONS),
        )

    def test_tasks_can_be_listed_created_and_deleted(self):
        listed = self.client.get("/tasks").get_json()
        self.assertEqual(listed["total"], len(listed["tasks"]))

        created = self.client.post("/tasks", json={"name": "Write the dependency policy"})
        self.assertEqual(created.status_code, 201)
        task_id = created.get_json()["id"]

        self.assertEqual(self.client.get(f"/tasks/{task_id}").status_code, 200)
        self.assertEqual(self.client.delete(f"/tasks/{task_id}").status_code, 204)
        self.assertEqual(self.client.get(f"/tasks/{task_id}").status_code, 404)

    def test_creating_a_task_without_a_name_is_rejected(self):
        response = self.client.post("/tasks", json={})

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.get_json()["error"], "validation_failed")

    def test_the_report_route_renders_the_task_names_with_jinja2(self):
        response = self.client.get("/tasks/report")

        self.assertEqual(response.status_code, 200)
        html = response.get_data(as_text=True)
        self.assertIn("Generate a CycloneDX SBOM", html)
        self.assertIn(self.settings["report"]["title"], html)

    def test_the_report_template_escapes_task_names(self):
        html = templates.render_task_report("Report", [{"name": "<script>x</script>", "done": False}])

        self.assertNotIn("<script>", html)
        self.assertIn("&lt;script&gt;", html)

    def test_a_token_round_trips_through_pyjwt(self):
        response = self.client.post("/auth/token", json={"username": "student"})
        self.assertEqual(response.status_code, 200)

        token = response.get_json()["token"]
        claims = auth.verify_token(
            token,
            signing_key=self.settings["auth"]["signing_key"],
            algorithms=(self.settings["auth"]["algorithm"],),
        )
        self.assertEqual(claims["sub"], "student")


if __name__ == "__main__":
    unittest.main()
