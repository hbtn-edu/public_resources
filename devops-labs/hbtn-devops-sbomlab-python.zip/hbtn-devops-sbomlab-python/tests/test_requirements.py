"""Checks on the seeded dependency pins themselves.

These tests import nothing outside the standard library, so they run in a bare
interpreter as well as inside the lab virtual environment.
"""

import pathlib
import unittest

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
REQUIREMENTS = REPO_ROOT / "requirements.txt"

SEEDED_PINS = {
    "flask": "2.0.1",
    "requests": "2.25.1",
    "urllib3": "1.26.4",
    "pyjwt": "2.3.0",
    "pyyaml": "5.3.1",
    "jinja2": "3.0.3",
}


def parse_requirements(path=REQUIREMENTS):
    """Return {normalised name: version} for every ``name==version`` line."""
    pins = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        name, separator, version = line.partition("==")
        if separator:
            pins[name.strip().lower()] = version.strip()
    return pins


class RequirementsTest(unittest.TestCase):
    def test_every_dependency_uses_an_exact_pin(self):
        text = REQUIREMENTS.read_text(encoding="utf-8")
        directives = [
            line.split("#", 1)[0].strip()
            for line in text.splitlines()
            if line.split("#", 1)[0].strip()
        ]
        self.assertEqual(len(directives), 6, "expected exactly six dependency lines")
        for directive in directives:
            self.assertIn("==", directive, f"{directive!r} is not pinned with ==")
            for operator in (">=", "<=", "~=", ">", "<", "!="):
                self.assertNotIn(operator, directive, f"{directive!r} uses a floating range")

    def test_the_seeded_baseline_is_preserved(self):
        """The vulnerable baseline must remain readable somewhere.

        Before the remediation task that is ``requirements.txt`` itself; once
        the pins are bumped it is ``requirements.txt.original``, the copy the
        remediation task asks for.
        """
        baseline = REPO_ROOT / "requirements.txt.original"
        source = baseline if baseline.exists() else REQUIREMENTS
        self.assertEqual(parse_requirements(source), SEEDED_PINS)


if __name__ == "__main__":
    unittest.main()
