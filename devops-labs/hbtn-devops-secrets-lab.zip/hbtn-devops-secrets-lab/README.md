# hbtn-devops-secrets-lab

Starter archive for the Holberton DevOps project **601 - Secrets &
Configuration Management**. You get it as `hbtn-devops-secrets-lab.zip` from
[the devops-labs folder of hbtn-edu/public_resources](https://github.com/hbtn-edu/public_resources/tree/main/devops-labs).

> ## This starter is intentionally insecure
>
> Credentials are hardcoded in the source, duplicated across files and
> committed to Git history. That is the exercise: you are going to find them,
> externalize them, purge them from history and install tooling that stops the
> next leak.
>
> **Every credential in this starter is fake.** Each one is prefixed
> `FAKE_`, carries a `DO NOT USE IN PRODUCTION` comment, and grants access to
> nothing. Never replace them with real values, not even locally.

## What is in here

| Path | What it is |
|---|---|
| `src/server.js` | Express application factory and entry point |
| `src/config.js` | Configuration module - the main offender |
| `src/db/connection.js` | Postgres connection pool |
| `src/routes/health.js` | `GET /health` |
| `src/routes/items.js` | `GET/POST/PUT/DELETE /items` (CRUD) |
| `src/routes/auth.js` | `POST /auth/token` - HMAC-signed session token |
| `src/middleware/` | Request logger, 404 handler, JSON error handler |
| `tests/` | 6 unit tests, none of which assert a credential value |
| `db/init/` | Schema and seed data applied by Postgres on first start |
| `Dockerfile` | Production image, pinned base, non-root user |
| `docker-compose.yml` | API + Postgres |
| `.gitleaks.toml` | Scanner configuration - see below |
| `.git/` | **Ships with this archive on purpose** - see [Git history](#git-history) |
| `make-history.sh` | Regenerates this starter and its Git history |

## API

| Method | Path | Auth | Notes |
|---|---|---|---|
| `GET` | `/health` | none | Always 200 when the process is up; database reachability is reported separately under `checks.database` |
| `POST` | `/auth/token` | none | `{"username": "..."}` -> HMAC-signed token |
| `GET` | `/items` | none | List |
| `GET` | `/items/:id` | none | Read |
| `POST` | `/items` | `x-api-key` | Create, 201 |
| `PUT` | `/items/:id` | `x-api-key` | Update |
| `DELETE` | `/items/:id` | `x-api-key` | Delete, 204 |

## Running it

With Docker (recommended - brings up Postgres too):

```bash
docker compose up -d --build
curl -s http://localhost:3000/health
docker compose down -v
```

Without Docker (the API starts, database-backed routes will not work):

```bash
npm ci
npm start
```

## Tests and linting

```bash
npm ci
npm test     # 6 unit tests, no database required
npm run lint
```

The tests mock the database layer and never assert the value of a credential,
so they keep passing once the credentials move to environment variables.

## Secret scanning

The lab credentials are low-entropy, human-readable strings. gitleaks' default
rule set is tuned for real credentials - high-entropy tokens and
provider-specific prefixes - and does **not** flag them: verified with gitleaks
8.18.1 and 8.30.1, both of which report zero findings on this repository
without extra configuration.

`.gitleaks.toml` therefore ships with the starter. It keeps the whole
default rule set (`useDefault = true`, so real AWS keys, GitHub tokens and
private keys are still detected) and adds one rule per lab credential. gitleaks
picks the file up automatically when it is run from the repository root:

```bash
gitleaks detect --no-git -v          # working tree
gitleaks detect --log-opts="--all"   # full history
```

A non-zero exit code from those commands is the expected result on the
unmodified starter.

> **Testing a scanner with a fake AWS key?** Recent gitleaks releases allowlist
> every AWS-shaped access key whose value ends in `EXAMPLE`, and that includes
> the canonical key printed throughout the AWS documentation. gitleaks 8.18.1
> still flags it; 8.30.1 does not. If you need a finding on any version,
> fabricate a key of the same shape whose last characters are something else.
> (No literal key is written here on purpose - it would show up as a finding in
> your own scans of this repository.)

## Git history

**This archive ships with its `.git` directory, and that is the one thing that
makes the lab possible.** Unzipping it gives you a working Git repository with
13 real commits: the credentials are introduced in the second commit and survive
to `HEAD`, so the history-rewriting tasks have something to rewrite.

> **Deleting `.git` destroys the lab.** The history cannot be reconstructed from
> the working tree, and every task that audits or rewrites it becomes
> impossible. Do not `rm -rf .git`, and if you copy the project elsewhere, copy
> `.git` with it.

Back up `.git` before experimenting (`cp -r .git .git-backup`). If a rewrite
goes wrong, download the archive again, into a clean directory, for a pristine
copy of the history:

```bash
curl -LO https://raw.githubusercontent.com/hbtn-edu/public_resources/main/devops-labs/hbtn-devops-secrets-lab.zip
unzip hbtn-devops-secrets-lab.zip
cd hbtn-devops-secrets-lab
```

`make-history.sh` regenerates the starter from scratch, deterministically. It
deletes and recreates everything in its own directory, including `.git`.

## Versions

Everything is pinned. No floating ranges, no `:latest` tags.

| Component | Version |
|---|---|
| Node.js | 20.20 (Alpine 3.22) in the image, >= 18 to run locally |
| express | 4.22.2 |
| pg | 8.22.0 |
| jest | 30.4.2 |
| supertest | 7.2.2 |
| eslint | 9.39.5 |
| postgres image | 16.14-alpine3.22 |
