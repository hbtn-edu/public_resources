-- Schema for the secrets lab API.
CREATE TABLE IF NOT EXISTS items (
    id         SERIAL       PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    done       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
