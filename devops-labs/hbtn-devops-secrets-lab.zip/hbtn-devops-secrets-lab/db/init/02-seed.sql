-- Seed rows so that GET /items returns something on a fresh stack.
INSERT INTO items (name, done) VALUES
    ('Rotate the database password', FALSE),
    ('Move credentials out of source control', FALSE),
    ('Install a pre-commit secret scanner', FALSE);
