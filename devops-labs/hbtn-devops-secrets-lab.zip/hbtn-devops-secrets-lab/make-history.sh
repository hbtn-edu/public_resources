#!/usr/bin/env bash
#
# make-history.sh - rebuild hbtn-devops-secrets-lab from scratch, including its
# Git history.
#
# Project 601 (Secrets & Configuration Management) Task 3 has students rewrite
# this repository's history with `git filter-repo`. That only works if the
# repository has a real, multi-commit history in which the fake credentials are
# introduced early and survive to HEAD. This script produces exactly that.
#
# It is deterministic: every commit has a fixed author, a fixed date and fixed
# file contents, so re-running it yields the same tree and the same commit
# sequence. The only moving part is `package-lock.json`, which is resolved from
# the npm registry (all direct dependencies are exact-pinned; transitive
# resolution can drift as the registry changes). Use SKIP_NPM=1 to reuse the
# lockfiles already committed in the repository instead of contacting npm.
#
# Usage:
#   ./make-history.sh              # full rebuild (needs network for npm)
#   SKIP_NPM=1 ./make-history.sh   # rebuild reusing the existing lockfiles
#
# WARNING: this deletes and recreates everything in its own directory,
# including .git. The canonical copy of this script lives with the curriculum
# starter assets; the copy committed inside the repository is rewritten by
# `git filter-repo` in Task 3 like every other file.
#
set -euo pipefail

# ---------------------------------------------------------------------------
# Re-exec from a temporary copy: the script is about to delete its own file.
# ---------------------------------------------------------------------------
if [ "${HISTGEN_RELAUNCHED:-0}" != "1" ]; then
  _self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
  _tmp="$(mktemp -t make-history.XXXXXX.sh)"
  cp "$_self" "$_tmp"
  chmod +x "$_tmp"
  HISTGEN_RELAUNCHED=1 HISTGEN_REPO_DIR="$(dirname "$_self")" HISTGEN_SELF="$_tmp" \
    exec bash "$_tmp" "$@"
fi

REPO="$HISTGEN_REPO_DIR"
SELF="$HISTGEN_SELF"
SKIP_NPM="${SKIP_NPM:-0}"
LOCK_CACHE="$(mktemp -d -t secrets-lab-locks.XXXXXX)"

echo "==> rebuilding $REPO"

# ---------------------------------------------------------------------------
# Preserve the existing lockfiles when SKIP_NPM=1
# ---------------------------------------------------------------------------
if [ "$SKIP_NPM" = "1" ]; then
  for stage in 1 2 3 4; do
    if [ -f "$REPO/.lockstages/package-lock.$stage.json" ]; then
      cp "$REPO/.lockstages/package-lock.$stage.json" "$LOCK_CACHE/$stage.json"
    fi
  done
  if [ ! -f "$LOCK_CACHE/4.json" ] && [ -f "$REPO/package-lock.json" ]; then
    for stage in 1 2 3 4; do cp "$REPO/package-lock.json" "$LOCK_CACHE/$stage.json"; done
  fi
fi

# ---------------------------------------------------------------------------
# Wipe
# ---------------------------------------------------------------------------
find "$REPO" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
mkdir -p "$REPO/src/routes" "$REPO/src/db" "$REPO/src/middleware" "$REPO/tests" "$REPO/db/init"

git -C "$REPO" init -q -b main
git -C "$REPO" config user.name  "Dana Okafor"
git -C "$REPO" config user.email "dana.okafor@example.com"
git -C "$REPO" config commit.gpgsign false

commit () {
  local when="$1" who="$2" msg="$3" name email
  case "$who" in
    dana) name="Dana Okafor";  email="dana.okafor@example.com" ;;
    luc)  name="Luc Ferrand";  email="luc.ferrand@example.com" ;;
    *)    echo "unknown author $who" >&2; exit 1 ;;
  esac
  git -C "$REPO" add -A
  GIT_AUTHOR_NAME="$name"    GIT_AUTHOR_EMAIL="$email"    GIT_AUTHOR_DATE="$when" \
  GIT_COMMITTER_NAME="$name" GIT_COMMITTER_EMAIL="$email" GIT_COMMITTER_DATE="$when" \
    git -C "$REPO" commit -q -m "$msg"
}

# Resolve package-lock.json for a given package.json stage.
lockfile () {
  local stage="$1"
  if [ -f "$LOCK_CACHE/$stage.json" ]; then
    cp "$LOCK_CACHE/$stage.json" "$REPO/package-lock.json"
    return
  fi
  ( cd "$REPO" && npm install --package-lock-only --no-audit --no-fund --silent )
  cp "$REPO/package-lock.json" "$LOCK_CACHE/$stage.json"
}

# ===========================================================================
# File writers
# ===========================================================================

write_package_json () {
  case "$1" in
  1)
    cat > "$REPO/package.json" <<'JSON'
{
  "name": "hbtn-devops-secrets-lab",
  "version": "0.1.0",
  "private": true,
  "description": "Training API for Holberton DevOps project 601 - deliberately stores fake credentials in source control.",
  "license": "MIT",
  "main": "src/server.js",
  "engines": {
    "node": ">=18.0.0"
  },
  "scripts": {
    "start": "node src/server.js",
    "test": "echo \"no tests yet\" && exit 0"
  },
  "dependencies": {
    "express": "4.22.2"
  }
}
JSON
    ;;
  2)
    cat > "$REPO/package.json" <<'JSON'
{
  "name": "hbtn-devops-secrets-lab",
  "version": "0.2.0",
  "private": true,
  "description": "Training API for Holberton DevOps project 601 - deliberately stores fake credentials in source control.",
  "license": "MIT",
  "main": "src/server.js",
  "engines": {
    "node": ">=18.0.0"
  },
  "scripts": {
    "start": "node src/server.js",
    "test": "echo \"no tests yet\" && exit 0"
  },
  "dependencies": {
    "express": "4.22.2",
    "pg": "8.22.0"
  }
}
JSON
    ;;
  3)
    cat > "$REPO/package.json" <<'JSON'
{
  "name": "hbtn-devops-secrets-lab",
  "version": "0.3.0",
  "private": true,
  "description": "Training API for Holberton DevOps project 601 - deliberately stores fake credentials in source control.",
  "license": "MIT",
  "main": "src/server.js",
  "engines": {
    "node": ">=18.0.0"
  },
  "scripts": {
    "start": "node src/server.js",
    "test": "jest"
  },
  "dependencies": {
    "express": "4.22.2",
    "pg": "8.22.0"
  },
  "devDependencies": {
    "jest": "30.4.2",
    "supertest": "7.2.2"
  }
}
JSON
    ;;
  4)
    cat > "$REPO/package.json" <<'JSON'
{
  "name": "hbtn-devops-secrets-lab",
  "version": "1.0.0",
  "private": true,
  "description": "Training API for Holberton DevOps project 601 - deliberately stores fake credentials in source control.",
  "license": "MIT",
  "main": "src/server.js",
  "engines": {
    "node": ">=18.0.0"
  },
  "scripts": {
    "start": "node src/server.js",
    "test": "jest",
    "lint": "eslint ."
  },
  "dependencies": {
    "express": "4.22.2",
    "pg": "8.22.0"
  },
  "devDependencies": {
    "@eslint/js": "9.39.5",
    "eslint": "9.39.5",
    "jest": "30.4.2",
    "supertest": "7.2.2"
  }
}
JSON
    ;;
  esac
}

write_gitignore () {
  # NOTE: `.env` is deliberately absent. Adding it is project 601 Task 2.
  cat > "$REPO/.gitignore" <<'TXT'
node_modules/
coverage/
npm-debug.log*
*.log
.DS_Store
.idea/
.vscode/
TXT
}

write_readme_stub () {
  cat > "$REPO/README.md" <<'MD'
# hbtn-devops-secrets-lab

Small Express API used as the starting point for the Holberton DevOps
"Secrets & Configuration Management" project.

```bash
npm install
npm start
```
MD
}

write_server_v1 () {
  cat > "$REPO/src/server.js" <<'JS'
'use strict';

const express = require('express');

const app = express();
app.use(express.json());

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

const PORT = 3000;

app.listen(PORT, () => {
  console.log(`secrets-lab listening on port ${PORT}`);
});

module.exports = app;
JS
}

write_config () {
  cat > "$REPO/src/config.js" <<'JS'
'use strict';

/*
 * Application configuration.
 *
 * !!! THIS FILE IS DELIBERATELY WRONG !!!
 *
 * Credentials are hardcoded below so that the Holberton DevOps "Secrets &
 * Configuration Management" project has something realistic to audit, scan,
 * externalize and purge from Git history. The values are NOT real credentials
 * and grant access to nothing.
 */

// DO NOT USE IN PRODUCTION - these are intentionally fake for training
const DB_PASSWORD  = "FAKE_DB_PASSWORD_FOR_TRAINING_ONLY";
const API_KEY      = "FAKE_API_KEY_ak_test_1234567890abcdef";
const OAUTH_SECRET = "FAKE_OAUTH_SECRET_os_test_fedcba0987654321";

const config = {
  app: {
    name: 'hbtn-devops-secrets-lab',
    port: 3000,
    env: 'development',
    logLevel: 'info',
  },
  db: {
    host: 'db',
    port: 5432,
    name: 'devops_lab',
    user: 'labuser',
    password: DB_PASSWORD,
  },
  auth: {
    apiKey: API_KEY,
    oauthSecret: OAUTH_SECRET,
    tokenTtlSeconds: 3600,
  },
};

module.exports = config;
JS
}

write_server_v2 () {
  cat > "$REPO/src/server.js" <<'JS'
'use strict';

const express = require('express');

const config = require('./config');

const app = express();
app.use(express.json());

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', service: config.app.name });
});

app.listen(config.app.port, () => {
  console.log(`${config.app.name} listening on port ${config.app.port}`);
});

module.exports = app;
JS
}

write_db_connection () {
  cat > "$REPO/src/db/connection.js" <<'JS'
'use strict';

const { Pool } = require('pg');

/*
 * The database password is repeated here instead of being imported from
 * ../config. That duplication is intentional: in real incidents a leaked
 * credential is almost never confined to a single file, and the audit in
 * Task 1 is only complete when every copy has been found.
 */

// DO NOT USE IN PRODUCTION - these are intentionally fake for training
const pool = new Pool({
  host: 'db',
  port: 5432,
  database: 'devops_lab',
  user: 'labuser',
  password: 'FAKE_DB_PASSWORD_FOR_TRAINING_ONLY',
  max: 5,
  idleTimeoutMillis: 10000,
  connectionTimeoutMillis: 3000,
});

pool.on('error', (err) => {
  console.error('[db] idle client error:', err.message);
});

async function query(text, params) {
  return pool.query(text, params);
}

async function ping() {
  try {
    await pool.query('SELECT 1');
    return true;
  } catch {
    return false;
  }
}

async function close() {
  await pool.end();
}

module.exports = { pool, query, ping, close };
JS
}

write_routes_health () {
  cat > "$REPO/src/routes/health.js" <<'JS'
'use strict';

const express = require('express');

const config = require('../config');
const db = require('../db/connection');
const pkg = require('../../package.json');

const router = express.Router();

/*
 * The service reports 200 whenever the process itself is healthy and states
 * database reachability separately, so the API can be exercised - and the unit
 * tests can run - without a live Postgres.
 */
router.get('/health', async (req, res) => {
  const databaseReachable = await db.ping();

  res.status(200).json({
    status: 'ok',
    service: config.app.name,
    version: pkg.version,
    uptimeSeconds: Math.floor(process.uptime()),
    checks: {
      database: databaseReachable ? 'connected' : 'unreachable',
    },
  });
});

module.exports = router;
JS
}

write_routes_items () {
  cat > "$REPO/src/routes/items.js" <<'JS'
'use strict';

const express = require('express');

const config = require('../config');
const db = require('../db/connection');

const router = express.Router();

const SELECT_COLUMNS = 'id, name, done, created_at';

function validateItem(payload) {
  const errors = [];

  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    errors.push('body must be a JSON object');
    return errors;
  }
  if (typeof payload.name !== 'string' || payload.name.trim() === '') {
    errors.push('name is required and must be a non-empty string');
  } else if (payload.name.trim().length > 255) {
    errors.push('name must be at most 255 characters');
  }
  if (payload.done !== undefined && typeof payload.done !== 'boolean') {
    errors.push('done must be a boolean');
  }
  return errors;
}

function requireApiKey(req, res, next) {
  if (req.get('x-api-key') !== config.auth.apiKey) {
    return res.status(401).json({
      error: 'unauthorized',
      message: 'missing or invalid x-api-key header',
    });
  }
  return next();
}

router.get('/items', async (req, res, next) => {
  try {
    const result = await db.query(`SELECT ${SELECT_COLUMNS} FROM items ORDER BY id`);
    res.status(200).json({ items: result.rows });
  } catch (err) {
    next(err);
  }
});

router.get('/items/:id', async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT ${SELECT_COLUMNS} FROM items WHERE id = $1`,
      [req.params.id],
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'not_found', message: 'no item with that id' });
    }
    return res.status(200).json(result.rows[0]);
  } catch (err) {
    return next(err);
  }
});

router.post('/items', requireApiKey, async (req, res, next) => {
  const errors = validateItem(req.body);
  if (errors.length > 0) {
    return res.status(400).json({ error: 'validation_failed', details: errors });
  }
  try {
    const result = await db.query(
      `INSERT INTO items (name, done) VALUES ($1, $2) RETURNING ${SELECT_COLUMNS}`,
      [req.body.name.trim(), req.body.done === true],
    );
    return res.status(201).json(result.rows[0]);
  } catch (err) {
    return next(err);
  }
});

router.put('/items/:id', requireApiKey, async (req, res, next) => {
  const errors = validateItem(req.body);
  if (errors.length > 0) {
    return res.status(400).json({ error: 'validation_failed', details: errors });
  }
  try {
    const result = await db.query(
      `UPDATE items SET name = $1, done = $2 WHERE id = $3 RETURNING ${SELECT_COLUMNS}`,
      [req.body.name.trim(), req.body.done === true, req.params.id],
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'not_found', message: 'no item with that id' });
    }
    return res.status(200).json(result.rows[0]);
  } catch (err) {
    return next(err);
  }
});

router.delete('/items/:id', requireApiKey, async (req, res, next) => {
  try {
    const result = await db.query('DELETE FROM items WHERE id = $1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'not_found', message: 'no item with that id' });
    }
    return res.status(204).send();
  } catch (err) {
    return next(err);
  }
});

module.exports = router;
JS
}

write_server_v3 () {
  cat > "$REPO/src/server.js" <<'JS'
'use strict';

const express = require('express');

const config = require('./config');
const healthRoutes = require('./routes/health');
const itemRoutes = require('./routes/items');

function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json());

  app.use(healthRoutes);
  app.use(itemRoutes);

  return app;
}

function start() {
  return createApp().listen(config.app.port, () => {
    console.log(`[${config.app.name}] listening on port ${config.app.port}`);
  });
}

if (require.main === module) {
  start();
}

module.exports = { createApp, start };
JS
}

write_routes_auth () {
  cat > "$REPO/src/routes/auth.js" <<'JS'
'use strict';

const crypto = require('crypto');
const express = require('express');

const config = require('../config');

const router = express.Router();

/*
 * A deliberately small token implementation - the point of this file is that
 * the OAuth client secret is genuinely used at runtime, so removing it from
 * source control in Task 2 has to be done properly rather than by deleting a
 * dead constant.
 */
function signToken(subject, issuedAtMs = Date.now()) {
  const issuedAt = Math.floor(issuedAtMs / 1000);
  const payload = Buffer.from(
    JSON.stringify({ sub: subject, iat: issuedAt, exp: issuedAt + config.auth.tokenTtlSeconds }),
  ).toString('base64url');

  const signature = crypto
    .createHmac('sha256', config.auth.oauthSecret)
    .update(payload)
    .digest('base64url');

  return `${payload}.${signature}`;
}

router.post('/auth/token', (req, res) => {
  const username = req.body && req.body.username;

  if (typeof username !== 'string' || username.trim() === '') {
    return res.status(400).json({
      error: 'validation_failed',
      details: ['username is required and must be a non-empty string'],
    });
  }

  return res.status(200).json({
    token: signToken(username.trim()),
    tokenType: 'Bearer',
    expiresIn: config.auth.tokenTtlSeconds,
  });
});

module.exports = router;
JS
}

write_server_v4 () {
  cat > "$REPO/src/server.js" <<'JS'
'use strict';

const express = require('express');

const config = require('./config');
const healthRoutes = require('./routes/health');
const itemRoutes = require('./routes/items');
const authRoutes = require('./routes/auth');

function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json());

  app.use(healthRoutes);
  app.use(authRoutes);
  app.use(itemRoutes);

  return app;
}

function start() {
  return createApp().listen(config.app.port, () => {
    console.log(`[${config.app.name}] listening on port ${config.app.port}`);
  });
}

if (require.main === module) {
  start();
}

module.exports = { createApp, start };
JS
}

write_middleware () {
  cat > "$REPO/src/middleware/request-logger.js" <<'JS'
'use strict';

const config = require('../config');

module.exports = function requestLogger(req, res, next) {
  if (process.env.NODE_ENV === 'test' || config.app.logLevel === 'silent') {
    return next();
  }

  const startedAt = process.hrtime.bigint();

  res.on('finish', () => {
    const elapsedMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
    console.log(
      `[${config.app.name}] ${req.method} ${req.originalUrl} ${res.statusCode} ${elapsedMs.toFixed(1)}ms`,
    );
  });

  return next();
};
JS

  cat > "$REPO/src/middleware/errors.js" <<'JS'
'use strict';

function notFound(req, res) {
  res.status(404).json({
    error: 'not_found',
    message: `no route for ${req.method} ${req.originalUrl}`,
  });
}

function errorHandler(err, req, res, next) {
  console.error('[error]', err.message);
  res.status(500).json({ error: 'internal_error', message: 'unexpected server error' });
}

module.exports = { notFound, errorHandler };
JS
}

write_server_v5 () {
  cat > "$REPO/src/server.js" <<'JS'
'use strict';

const express = require('express');

const config = require('./config');
const healthRoutes = require('./routes/health');
const itemRoutes = require('./routes/items');
const authRoutes = require('./routes/auth');
const requestLogger = require('./middleware/request-logger');
const { notFound, errorHandler } = require('./middleware/errors');

function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json());
  app.use(requestLogger);

  app.use(healthRoutes);
  app.use(authRoutes);
  app.use(itemRoutes);

  app.use(notFound);
  app.use(errorHandler);

  return app;
}

function start() {
  return createApp().listen(config.app.port, () => {
    console.log(`[${config.app.name}] listening on port ${config.app.port}`);
  });
}

if (require.main === module) {
  start();
}

module.exports = { createApp, start };
JS
}

write_sql () {
  cat > "$REPO/db/init/01-schema.sql" <<'SQL'
-- Schema for the secrets lab API.
CREATE TABLE IF NOT EXISTS items (
    id         SERIAL       PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    done       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
SQL

  cat > "$REPO/db/init/02-seed.sql" <<'SQL'
-- Seed rows so that GET /items returns something on a fresh stack.
INSERT INTO items (name, done) VALUES
    ('Rotate the database password', FALSE),
    ('Move credentials out of source control', FALSE),
    ('Install a pre-commit secret scanner', FALSE);
SQL
}

write_tests_first_batch () {
  cat > "$REPO/tests/config.test.js" <<'JS'
'use strict';

const config = require('../src/config');

describe('configuration module', () => {
  test('exposes the app, db and auth sections', () => {
    expect(config).toEqual(
      expect.objectContaining({
        app: expect.any(Object),
        db: expect.any(Object),
        auth: expect.any(Object),
      }),
    );

    expect(config.app.name).toEqual(expect.any(String));
    expect(config.app.port).toEqual(expect.any(Number));
    expect(config.db.host).toEqual(expect.any(String));
    expect(config.db.port).toEqual(expect.any(Number));
    expect(config.db.name).toEqual(expect.any(String));
    expect(config.db.user).toEqual(expect.any(String));
    expect(config.auth.tokenTtlSeconds).toEqual(expect.any(Number));
  });

  test('provides non-empty credentials without asserting their values', () => {
    // Deliberately value-agnostic. These assertions must keep passing after
    // the credentials move from source code to environment variables, so they
    // check the shape of the configuration and never the secret itself.
    for (const secret of [config.db.password, config.auth.apiKey, config.auth.oauthSecret]) {
      expect(typeof secret).toBe('string');
      expect(secret.length).toBeGreaterThan(0);
    }
  });
});
JS

  cat > "$REPO/tests/health.test.js" <<'JS'
'use strict';

jest.mock('../src/db/connection', () => ({
  pool: {},
  query: jest.fn(),
  ping: jest.fn().mockResolvedValue(true),
  close: jest.fn(),
}));

const request = require('supertest');

const { createApp } = require('../src/server');

describe('health endpoint and routing', () => {
  const app = createApp();

  test('GET /health reports status ok with service metadata', async () => {
    const res = await request(app).get('/health');

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.checks.database).toBe('connected');
    expect(res.body.service).toEqual(expect.any(String));
    expect(res.body.uptimeSeconds).toEqual(expect.any(Number));
  });

  test('an unknown route returns a JSON 404', async () => {
    const res = await request(app).get('/definitely-not-a-route');

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('not_found');
  });
});
JS
}

write_tests_second_batch () {
  cat > "$REPO/tests/items.test.js" <<'JS'
'use strict';

jest.mock('../src/db/connection', () => ({
  pool: {},
  query: jest.fn(),
  ping: jest.fn().mockResolvedValue(true),
  close: jest.fn(),
}));

const request = require('supertest');

const db = require('../src/db/connection');
const config = require('../src/config');
const { createApp } = require('../src/server');

describe('items routes', () => {
  const app = createApp();

  beforeEach(() => {
    db.query.mockReset();
  });

  test('GET /items returns the rows provided by the data layer', async () => {
    db.query.mockResolvedValue({
      rows: [{ id: 1, name: 'Rotate the database password', done: false, created_at: '2024-03-08T09:22:00.000Z' }],
    });

    const res = await request(app).get('/items');

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].name).toBe('Rotate the database password');
  });

  test('POST /items rejects a payload with no name before touching the database', async () => {
    const res = await request(app)
      .post('/items')
      .set('x-api-key', config.auth.apiKey)
      .send({});

    expect(res.status).toBe(400);
    expect(res.body.error).toBe('validation_failed');
    expect(db.query).not.toHaveBeenCalled();
  });
});
JS
}

write_docker () {
  cat > "$REPO/Dockerfile" <<'DOCKER'
# hbtn-devops-secrets-lab
#
# Pinned base image - there is no `:latest` anywhere in this repository.
FROM node:20.20-alpine3.22

WORKDIR /app

# Install production dependencies from the committed lockfile.
COPY package.json package-lock.json ./
RUN npm ci --omit=dev && npm cache clean --force

COPY src ./src

ENV NODE_ENV=production
EXPOSE 3000

USER node

HEALTHCHECK --interval=10s --timeout=3s --start-period=5s --retries=3 \
  CMD node -e "require('http').get('http://127.0.0.1:3000/health', (r) => process.exit(r.statusCode === 200 ? 0 : 1)).on('error', () => process.exit(1))"

CMD ["node", "src/server.js"]
DOCKER

  cat > "$REPO/.dockerignore" <<'TXT'
.git
.gitignore
node_modules
coverage
tests
docker-compose.yml
Dockerfile
.dockerignore
README.md
make-history.sh
*.log
TXT
}

write_compose () {
  cat > "$REPO/docker-compose.yml" <<'YAML'
# hbtn-devops-secrets-lab - baseline stack.
#
# Part of the deliberately insecure starting point: the database password sits
# in plain text below, exactly like the values in src/. Project 601 Task 2
# replaces it with an environment-variable reference.
services:
  db:
    image: postgres:16.14-alpine3.22
    container_name: secrets-lab-db
    environment:
      POSTGRES_DB: devops_lab
      POSTGRES_USER: labuser
      # DO NOT USE IN PRODUCTION - these are intentionally fake for training
      POSTGRES_PASSWORD: FAKE_DB_PASSWORD_FOR_TRAINING_ONLY
    volumes:
      - ./db/init:/docker-entrypoint-initdb.d:ro
      - db-data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U labuser -d devops_lab"]
      interval: 5s
      timeout: 3s
      retries: 10
    restart: unless-stopped

  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: secrets-lab-app
    ports:
      - "3000:3000"
    depends_on:
      db:
        condition: service_healthy
    restart: unless-stopped

volumes:
  db-data:
YAML
}

write_eslint () {
  cat > "$REPO/eslint.config.js" <<'JS'
'use strict';

const js = require('@eslint/js');

const nodeGlobals = {
  require: 'readonly',
  module: 'writable',
  exports: 'writable',
  process: 'readonly',
  console: 'readonly',
  Buffer: 'readonly',
  URL: 'readonly',
  __dirname: 'readonly',
  __filename: 'readonly',
  setTimeout: 'readonly',
  clearTimeout: 'readonly',
  setInterval: 'readonly',
  clearInterval: 'readonly',
};

const jestGlobals = {
  describe: 'readonly',
  test: 'readonly',
  expect: 'readonly',
  jest: 'readonly',
  beforeAll: 'readonly',
  afterAll: 'readonly',
  beforeEach: 'readonly',
  afterEach: 'readonly',
};

module.exports = [
  { ignores: ['node_modules/**', 'coverage/**'] },
  js.configs.recommended,
  {
    files: ['**/*.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'commonjs',
      globals: nodeGlobals,
    },
    rules: {
      'no-unused-vars': ['error', { args: 'after-used', argsIgnorePattern: '^_|^next$' }],
    },
  },
  {
    files: ['tests/**/*.js'],
    languageOptions: {
      globals: { ...nodeGlobals, ...jestGlobals },
    },
  },
];
JS
}

write_readme_full () {
  cat > "$REPO/README.md" <<'MD'
# hbtn-devops-secrets-lab

Starter repository for the Holberton DevOps project **601 - Secrets &
Configuration Management**.

> ## This repository is intentionally insecure
>
> Credentials are hardcoded in the source, duplicated across files and
> committed to Git history. That is the exercise: you are going to find them,
> externalize them, purge them from history and install tooling that stops the
> next leak.
>
> **Every credential in this repository is fake.** Each one is prefixed
> `FAKE_`, carries a `DO NOT USE IN PRODUCTION` comment, and grants access to
> nothing. Never replace them with real values, not even locally.

## What is in here

| Path | What it is |
|---|---|
| `src/server.js` | Express application factory and entry point |
| `src/config.js` | Configuration module - the main offender |
| `src/db/connection.js` | Postgres connection pool |
| `src/routes/health.js` | `GET /health` |
| `src/routes/items.js` | `GET/POST/PUT/DELETE /items` (CRUD) |
| `src/routes/auth.js` | `POST /auth/token` - HMAC-signed session token |
| `src/middleware/` | Request logger, 404 handler, JSON error handler |
| `tests/` | 6 unit tests, none of which assert a credential value |
| `db/init/` | Schema and seed data applied by Postgres on first start |
| `Dockerfile` | Production image, pinned base, non-root user |
| `docker-compose.yml` | API + Postgres |
| `.gitleaks.toml` | Scanner configuration - see below |
| `make-history.sh` | Regenerates this repository and its Git history |

## API

| Method | Path | Auth | Notes |
|---|---|---|---|
| `GET` | `/health` | none | Always 200 when the process is up; database reachability is reported separately under `checks.database` |
| `POST` | `/auth/token` | none | `{"username": "..."}` -> HMAC-signed token |
| `GET` | `/items` | none | List |
| `GET` | `/items/:id` | none | Read |
| `POST` | `/items` | `x-api-key` | Create, 201 |
| `PUT` | `/items/:id` | `x-api-key` | Update |
| `DELETE` | `/items/:id` | `x-api-key` | Delete, 204 |

## Running it

With Docker (recommended - brings up Postgres too):

```bash
docker compose up -d --build
curl -s http://localhost:3000/health
docker compose down -v
```

Without Docker (the API starts, database-backed routes will not work):

```bash
npm ci
npm start
```

## Tests and linting

```bash
npm ci
npm test     # 6 unit tests, no database required
npm run lint
```

The tests mock the database layer and never assert the value of a credential,
so they keep passing once the credentials move to environment variables.

## Secret scanning

The lab credentials are low-entropy, human-readable strings. gitleaks' default
rule set is tuned for real credentials - high-entropy tokens and
provider-specific prefixes - and does **not** flag them: verified with gitleaks
8.18.1 and 8.30.1, both of which report zero findings on this repository
without extra configuration.

`.gitleaks.toml` therefore ships with the repository. It keeps the whole
default rule set (`useDefault = true`, so real AWS keys, GitHub tokens and
private keys are still detected) and adds one rule per lab credential. gitleaks
picks the file up automatically when it is run from the repository root:

```bash
gitleaks detect --no-git -v          # working tree
gitleaks detect --log-opts="--all"   # full history
```

A non-zero exit code from those commands is the expected result on the
unmodified starter.

> **Testing a scanner with a fake AWS key?** Recent gitleaks releases allowlist
> every AWS-shaped access key whose value ends in `EXAMPLE`, and that includes
> the canonical key printed throughout the AWS documentation. gitleaks 8.18.1
> still flags it; 8.30.1 does not. If you need a finding on any version,
> fabricate a key of the same shape whose last characters are something else.
> (No literal key is written here on purpose - it would show up as a finding in
> your own scans of this repository.)

## Git history

The history is real: the credentials are introduced in the second commit and
survive to `HEAD`, so history-rewriting tools have something to rewrite. Back
up `.git` before experimenting, and re-clone if a rewrite goes wrong.

`make-history.sh` regenerates the repository from scratch, deterministically.
It deletes and recreates everything in its own directory, including `.git`.

## Versions

Everything is pinned. No floating ranges, no `:latest` tags.

| Component | Version |
|---|---|
| Node.js | 20.20 (Alpine 3.22) in the image, >= 18 to run locally |
| express | 4.22.2 |
| pg | 8.22.0 |
| jest | 30.4.2 |
| supertest | 7.2.2 |
| eslint | 9.39.5 |
| postgres image | 16.14-alpine3.22 |
MD
}

write_gitleaks_config () {
  cat > "$REPO/.gitleaks.toml" <<'TOML'
# ---------------------------------------------------------------------------
# gitleaks configuration for hbtn-devops-secrets-lab
#
# Why this file exists
# --------------------
# This lab's credentials are deliberately fake, low-entropy and
# human-readable. gitleaks' default rules target real credentials - high
# entropy strings and provider-specific prefixes such as AKIA... or ghp_... -
# and do not match them. Verified empirically: gitleaks 8.18.1 and 8.30.1 both
# report "no leaks found" on this repository with the default rule set only.
#
# Project 601 Task 1 asks students to confirm a manual audit with a scanner, so
# the three lab credentials need explicit rules. The default rule set is kept
# (`useDefault = true`) so genuinely dangerous patterns are still detected -
# Task 6's pre-commit exercise depends on that.
#
# gitleaks loads this file automatically when it is run with the repository
# root as its source, so no --config flag is needed.
# ---------------------------------------------------------------------------

title = "hbtn-devops-secrets-lab"

[extend]
useDefault = true

# Files that quote the lab credentials as data rather than using them as
# credentials. Each entry is a deliberate, documented suppression:
#
#   .gitleaks.toml     this file - the rules below contain the literals
#   make-history.sh    the repository generator - it writes the source files
#   audit.md           Task 1 deliverable - the inventory table of the values
#   gitleaks_*.txt     Task 1 and Task 3 scanner reports kept as evidence
#   replacements.txt   Task 3 input file for `git filter-repo --replace-text`
#   .git-backup/       Task 3 safety copy of .git, taken before the rewrite
#
# Without these, the evidence a student is told to produce would itself trip
# the scanner and the post-cleanup scans could never come back clean.

[[rules]]
id = "hbtn-training-db-password"
description = "Hardcoded training database password (fake - lab only)"
regex = '''FAKE_DB_PASSWORD_FOR_TRAINING_ONLY'''
keywords = ["fake_db_password"]
tags = ["training", "password", "hbtn-601"]
  [rules.allowlist]
  description = "Documentation and scanner evidence, not credential usage"
  paths = [
    '''(^|/)\.gitleaks\.toml$''',
    '''(^|/)make-history\.sh$''',
    '''(^|/)audit\.md$''',
    '''(^|/)gitleaks_[A-Za-z0-9_.-]*\.(txt|json|sarif)$''',
    '''(^|/)replacements\.txt$''',
    '''(^|/)\.git-backup/''',
  ]

[[rules]]
id = "hbtn-training-api-key"
description = "Hardcoded training API key (fake - lab only)"
regex = '''FAKE_API_KEY_ak_test_[0-9a-f]{16}'''
keywords = ["fake_api_key"]
tags = ["training", "api-key", "hbtn-601"]
  [rules.allowlist]
  description = "Documentation and scanner evidence, not credential usage"
  paths = [
    '''(^|/)\.gitleaks\.toml$''',
    '''(^|/)make-history\.sh$''',
    '''(^|/)audit\.md$''',
    '''(^|/)gitleaks_[A-Za-z0-9_.-]*\.(txt|json|sarif)$''',
    '''(^|/)replacements\.txt$''',
    '''(^|/)\.git-backup/''',
  ]

[[rules]]
id = "hbtn-training-oauth-secret"
description = "Hardcoded training OAuth client secret (fake - lab only)"
regex = '''FAKE_OAUTH_SECRET_os_test_[0-9a-f]{16}'''
keywords = ["fake_oauth_secret"]
tags = ["training", "oauth", "hbtn-601"]
  [rules.allowlist]
  description = "Documentation and scanner evidence, not credential usage"
  paths = [
    '''(^|/)\.gitleaks\.toml$''',
    '''(^|/)make-history\.sh$''',
    '''(^|/)audit\.md$''',
    '''(^|/)gitleaks_[A-Za-z0-9_.-]*\.(txt|json|sarif)$''',
    '''(^|/)replacements\.txt$''',
    '''(^|/)\.git-backup/''',
  ]
TOML
}

# ===========================================================================
# History
# ===========================================================================

# --- 1 -------------------------------------------------------------- skeleton
write_package_json 1
write_gitignore
write_readme_stub
write_server_v1
lockfile 1
commit "2024-03-04T09:12:33+01:00" dana "chore: bootstrap express api skeleton

Minimal service with a hardcoded port and a single /health route."

# --- 2 ------------------------------------------- secrets enter the repository
write_config
write_server_v2
commit "2024-03-05T11:40:07+01:00" dana "feat: extract configuration into a config module

Collects the port, the database coordinates and the API credentials in one
place so the routes stop hardcoding them individually."

# --- 3 --------------------------------------------------- database + lockfile
write_package_json 2
write_db_connection
lockfile 2
commit "2024-03-06T14:05:52+01:00" dana "feat: add postgres connection pool

Adds pg and a small query/ping wrapper around a shared pool."

# --- 4 ------------------------------------------------------------- CRUD API
write_routes_health
write_routes_items
write_server_v3
write_sql
commit "2024-03-08T10:22:41+01:00" luc "feat: add items CRUD routes and schema

GET/POST/PUT/DELETE /items backed by Postgres, plus the init SQL that compose
applies on first start. Writes require the x-api-key header."

# --- 5 -------------------------------------------------------- token endpoint
write_routes_auth
write_server_v4
commit "2024-03-11T16:47:19+01:00" dana "feat: sign session tokens with the oauth secret

POST /auth/token returns an HMAC-signed, time-limited token."

# --- 6 --------------------------------------------------------- middleware
write_middleware
write_server_v5
commit "2024-03-13T09:58:04+01:00" luc "feat: add request logging and json error handling

Every response now carries a JSON body, including 404s and unexpected errors."

# --- 7 --------------------------------------------------------- first tests
write_package_json 3
write_tests_first_batch
lockfile 3
commit "2024-03-15T15:30:26+01:00" dana "test: add unit tests for config and health

Jest plus supertest. The database layer is mocked so the suite runs without a
live Postgres."

# --- 8 -------------------------------------------------------- more tests
write_tests_second_batch
commit "2024-03-19T11:15:48+01:00" luc "test: cover items listing and payload validation"

# --- 9 --------------------------------------------------------- container
write_docker
commit "2024-03-21T17:03:12+01:00" dana "chore: containerize the api

Pinned node base image, npm ci from the lockfile, non-root user, healthcheck."

# --- 10 ---------------------------------------------- compose stack (3rd leak)
write_compose
commit "2024-03-26T10:41:35+01:00" dana "chore: add compose stack with postgres

One command brings up the API and its database with the seed data."

# --- 11 ------------------------------------------------------------- linting
write_package_json 4
write_eslint
lockfile 4
commit "2024-04-02T13:26:57+01:00" luc "chore: add eslint flat config and lint script"

# --- 12 ---------------------------------------------------------------- docs
write_readme_full
commit "2024-04-09T09:34:11+01:00" dana "docs: document the api, the stack and the lab intent"

# --- 13 -------------------------------------------- scanner config + generator
write_gitleaks_config
cp "$SELF" "$REPO/make-history.sh"
chmod +x "$REPO/make-history.sh"
commit "2024-04-12T16:20:29+01:00" dana "chore: add gitleaks config and the history generator

The default gitleaks rules do not match the lab's low-entropy training values,
so the repository ships explicit rules for them on top of the defaults."

rm -rf "$LOCK_CACHE"

echo "==> done"
git -C "$REPO" --no-pager log --oneline
echo
echo "commits: $(git -C "$REPO" rev-list --count HEAD)"
