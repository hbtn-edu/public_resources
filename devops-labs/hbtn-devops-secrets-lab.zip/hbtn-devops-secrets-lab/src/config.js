'use strict';

/*
 * Application configuration.
 *
 * !!! THIS FILE IS DELIBERATELY WRONG !!!
 *
 * Credentials are hardcoded below so that the Holberton DevOps "Secrets &
 * Configuration Management" project has something realistic to audit, scan,
 * externalize and purge from Git history. The values are NOT real credentials
 * and grant access to nothing.
 */

// DO NOT USE IN PRODUCTION - these are intentionally fake for training
const DB_PASSWORD  = "FAKE_DB_PASSWORD_FOR_TRAINING_ONLY";
const API_KEY      = "FAKE_API_KEY_ak_test_1234567890abcdef";
const OAUTH_SECRET = "FAKE_OAUTH_SECRET_os_test_fedcba0987654321";

const config = {
  app: {
    name: 'hbtn-devops-secrets-lab',
    port: 3000,
    env: 'development',
    logLevel: 'info',
  },
  db: {
    host: 'db',
    port: 5432,
    name: 'devops_lab',
    user: 'labuser',
    password: DB_PASSWORD,
  },
  auth: {
    apiKey: API_KEY,
    oauthSecret: OAUTH_SECRET,
    tokenTtlSeconds: 3600,
  },
};

module.exports = config;
