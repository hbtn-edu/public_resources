'use strict';

const { Pool } = require('pg');

/*
 * The database password is repeated here instead of being imported from
 * ../config. That duplication is intentional: in real incidents a leaked
 * credential is almost never confined to a single file, and the audit in
 * Task 1 is only complete when every copy has been found.
 */

// DO NOT USE IN PRODUCTION - these are intentionally fake for training
const pool = new Pool({
  host: 'db',
  port: 5432,
  database: 'devops_lab',
  user: 'labuser',
  password: 'FAKE_DB_PASSWORD_FOR_TRAINING_ONLY',
  max: 5,
  idleTimeoutMillis: 10000,
  connectionTimeoutMillis: 3000,
});

pool.on('error', (err) => {
  console.error('[db] idle client error:', err.message);
});

async function query(text, params) {
  return pool.query(text, params);
}

async function ping() {
  try {
    await pool.query('SELECT 1');
    return true;
  } catch {
    return false;
  }
}

async function close() {
  await pool.end();
}

module.exports = { pool, query, ping, close };
