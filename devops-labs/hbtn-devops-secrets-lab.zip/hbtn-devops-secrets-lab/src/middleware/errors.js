'use strict';

function notFound(req, res) {
  res.status(404).json({
    error: 'not_found',
    message: `no route for ${req.method} ${req.originalUrl}`,
  });
}

function errorHandler(err, req, res, next) {
  console.error('[error]', err.message);
  res.status(500).json({ error: 'internal_error', message: 'unexpected server error' });
}

module.exports = { notFound, errorHandler };
