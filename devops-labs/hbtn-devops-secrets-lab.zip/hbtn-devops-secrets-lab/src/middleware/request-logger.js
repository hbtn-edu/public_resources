'use strict';

const config = require('../config');

module.exports = function requestLogger(req, res, next) {
  if (process.env.NODE_ENV === 'test' || config.app.logLevel === 'silent') {
    return next();
  }

  const startedAt = process.hrtime.bigint();

  res.on('finish', () => {
    const elapsedMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
    console.log(
      `[${config.app.name}] ${req.method} ${req.originalUrl} ${res.statusCode} ${elapsedMs.toFixed(1)}ms`,
    );
  });

  return next();
};
