'use strict';

const crypto = require('crypto');
const express = require('express');

const config = require('../config');

const router = express.Router();

/*
 * A deliberately small token implementation - the point of this file is that
 * the OAuth client secret is genuinely used at runtime, so removing it from
 * source control in Task 2 has to be done properly rather than by deleting a
 * dead constant.
 */
function signToken(subject, issuedAtMs = Date.now()) {
  const issuedAt = Math.floor(issuedAtMs / 1000);
  const payload = Buffer.from(
    JSON.stringify({ sub: subject, iat: issuedAt, exp: issuedAt + config.auth.tokenTtlSeconds }),
  ).toString('base64url');

  const signature = crypto
    .createHmac('sha256', config.auth.oauthSecret)
    .update(payload)
    .digest('base64url');

  return `${payload}.${signature}`;
}

router.post('/auth/token', (req, res) => {
  const username = req.body && req.body.username;

  if (typeof username !== 'string' || username.trim() === '') {
    return res.status(400).json({
      error: 'validation_failed',
      details: ['username is required and must be a non-empty string'],
    });
  }

  return res.status(200).json({
    token: signToken(username.trim()),
    tokenType: 'Bearer',
    expiresIn: config.auth.tokenTtlSeconds,
  });
});

module.exports = router;
