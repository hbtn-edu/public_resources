'use strict';

const express = require('express');

const config = require('../config');
const db = require('../db/connection');
const pkg = require('../../package.json');

const router = express.Router();

/*
 * The service reports 200 whenever the process itself is healthy and states
 * database reachability separately, so the API can be exercised - and the unit
 * tests can run - without a live Postgres.
 */
router.get('/health', async (req, res) => {
  const databaseReachable = await db.ping();

  res.status(200).json({
    status: 'ok',
    service: config.app.name,
    version: pkg.version,
    uptimeSeconds: Math.floor(process.uptime()),
    checks: {
      database: databaseReachable ? 'connected' : 'unreachable',
    },
  });
});

module.exports = router;
