'use strict';

const express = require('express');

const config = require('../config');
const db = require('../db/connection');

const router = express.Router();

const SELECT_COLUMNS = 'id, name, done, created_at';

function validateItem(payload) {
  const errors = [];

  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    errors.push('body must be a JSON object');
    return errors;
  }
  if (typeof payload.name !== 'string' || payload.name.trim() === '') {
    errors.push('name is required and must be a non-empty string');
  } else if (payload.name.trim().length > 255) {
    errors.push('name must be at most 255 characters');
  }
  if (payload.done !== undefined && typeof payload.done !== 'boolean') {
    errors.push('done must be a boolean');
  }
  return errors;
}

function requireApiKey(req, res, next) {
  if (req.get('x-api-key') !== config.auth.apiKey) {
    return res.status(401).json({
      error: 'unauthorized',
      message: 'missing or invalid x-api-key header',
    });
  }
  return next();
}

router.get('/items', async (req, res, next) => {
  try {
    const result = await db.query(`SELECT ${SELECT_COLUMNS} FROM items ORDER BY id`);
    res.status(200).json({ items: result.rows });
  } catch (err) {
    next(err);
  }
});

router.get('/items/:id', async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT ${SELECT_COLUMNS} FROM items WHERE id = $1`,
      [req.params.id],
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'not_found', message: 'no item with that id' });
    }
    return res.status(200).json(result.rows[0]);
  } catch (err) {
    return next(err);
  }
});

router.post('/items', requireApiKey, async (req, res, next) => {
  const errors = validateItem(req.body);
  if (errors.length > 0) {
    return res.status(400).json({ error: 'validation_failed', details: errors });
  }
  try {
    const result = await db.query(
      `INSERT INTO items (name, done) VALUES ($1, $2) RETURNING ${SELECT_COLUMNS}`,
      [req.body.name.trim(), req.body.done === true],
    );
    return res.status(201).json(result.rows[0]);
  } catch (err) {
    return next(err);
  }
});

router.put('/items/:id', requireApiKey, async (req, res, next) => {
  const errors = validateItem(req.body);
  if (errors.length > 0) {
    return res.status(400).json({ error: 'validation_failed', details: errors });
  }
  try {
    const result = await db.query(
      `UPDATE items SET name = $1, done = $2 WHERE id = $3 RETURNING ${SELECT_COLUMNS}`,
      [req.body.name.trim(), req.body.done === true, req.params.id],
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'not_found', message: 'no item with that id' });
    }
    return res.status(200).json(result.rows[0]);
  } catch (err) {
    return next(err);
  }
});

router.delete('/items/:id', requireApiKey, async (req, res, next) => {
  try {
    const result = await db.query('DELETE FROM items WHERE id = $1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'not_found', message: 'no item with that id' });
    }
    return res.status(204).send();
  } catch (err) {
    return next(err);
  }
});

module.exports = router;
