'use strict';

const express = require('express');

const config = require('./config');
const healthRoutes = require('./routes/health');
const itemRoutes = require('./routes/items');
const authRoutes = require('./routes/auth');
const requestLogger = require('./middleware/request-logger');
const { notFound, errorHandler } = require('./middleware/errors');

function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json());
  app.use(requestLogger);

  app.use(healthRoutes);
  app.use(authRoutes);
  app.use(itemRoutes);

  app.use(notFound);
  app.use(errorHandler);

  return app;
}

function start() {
  return createApp().listen(config.app.port, () => {
    console.log(`[${config.app.name}] listening on port ${config.app.port}`);
  });
}

if (require.main === module) {
  start();
}

module.exports = { createApp, start };
