'use strict';

const config = require('../src/config');

describe('configuration module', () => {
  test('exposes the app, db and auth sections', () => {
    expect(config).toEqual(
      expect.objectContaining({
        app: expect.any(Object),
        db: expect.any(Object),
        auth: expect.any(Object),
      }),
    );

    expect(config.app.name).toEqual(expect.any(String));
    expect(config.app.port).toEqual(expect.any(Number));
    expect(config.db.host).toEqual(expect.any(String));
    expect(config.db.port).toEqual(expect.any(Number));
    expect(config.db.name).toEqual(expect.any(String));
    expect(config.db.user).toEqual(expect.any(String));
    expect(config.auth.tokenTtlSeconds).toEqual(expect.any(Number));
  });

  test('provides non-empty credentials without asserting their values', () => {
    // Deliberately value-agnostic. These assertions must keep passing after
    // the credentials move from source code to environment variables, so they
    // check the shape of the configuration and never the secret itself.
    for (const secret of [config.db.password, config.auth.apiKey, config.auth.oauthSecret]) {
      expect(typeof secret).toBe('string');
      expect(secret.length).toBeGreaterThan(0);
    }
  });
});
