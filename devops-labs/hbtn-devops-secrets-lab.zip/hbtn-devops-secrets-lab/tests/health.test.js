'use strict';

jest.mock('../src/db/connection', () => ({
  pool: {},
  query: jest.fn(),
  ping: jest.fn().mockResolvedValue(true),
  close: jest.fn(),
}));

const request = require('supertest');

const { createApp } = require('../src/server');

describe('health endpoint and routing', () => {
  const app = createApp();

  test('GET /health reports status ok with service metadata', async () => {
    const res = await request(app).get('/health');

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.checks.database).toBe('connected');
    expect(res.body.service).toEqual(expect.any(String));
    expect(res.body.uptimeSeconds).toEqual(expect.any(Number));
  });

  test('an unknown route returns a JSON 404', async () => {
    const res = await request(app).get('/definitely-not-a-route');

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('not_found');
  });
});
