'use strict';

jest.mock('../src/db/connection', () => ({
  pool: {},
  query: jest.fn(),
  ping: jest.fn().mockResolvedValue(true),
  close: jest.fn(),
}));

const request = require('supertest');

const db = require('../src/db/connection');
const config = require('../src/config');
const { createApp } = require('../src/server');

describe('items routes', () => {
  const app = createApp();

  beforeEach(() => {
    db.query.mockReset();
  });

  test('GET /items returns the rows provided by the data layer', async () => {
    db.query.mockResolvedValue({
      rows: [{ id: 1, name: 'Rotate the database password', done: false, created_at: '2024-03-08T09:22:00.000Z' }],
    });

    const res = await request(app).get('/items');

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].name).toBe('Rotate the database password');
  });

  test('POST /items rejects a payload with no name before touching the database', async () => {
    const res = await request(app)
      .post('/items')
      .set('x-api-key', config.auth.apiKey)
      .send({});

    expect(res.status).toBe(400);
    expect(res.body.error).toBe('validation_failed');
    expect(db.query).not.toHaveBeenCalled();
  });
});
